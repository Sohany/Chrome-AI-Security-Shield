// popup.js
document.addEventListener('DOMContentLoaded', () => {
  const tabs = document.querySelectorAll('.tabbtn');
  tabs.forEach(b => b.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.style.display = 'none');
    document.getElementById(b.dataset.tab).style.display = 'block';
  }));

  const meterFill = document.getElementById('meterFill');
  const meterLabel = document.getElementById('meterLabel');
  const reasonEl = document.getElementById('analysisReason');
  const toggleBtn = document.getElementById('toggleBtn');
  const antivirusBtn = document.getElementById('antivirusBtn');
  const shieldIcon = document.getElementById('shieldIcon');
  const historyList = document.getElementById('historyList');
  const clearHistory = document.getElementById('clearHistory');

  document.querySelector('.tabbtn[data-tab="analysis"]').click();

  function refreshMeterFromHistory() {
    chrome.runtime.sendMessage({ type: 'get_history' }, (hist = []) => {
      const latest = (hist && hist[0]) || null;
      if (!latest) {
        meterFill.style.width = '20%';
        meterFill.textContent = '20%';
        meterLabel.textContent = 'No recent findings';
        reasonEl.textContent = '';
      } else {
        const trust = Math.max(0, Math.round((1 - (latest.confidence||0)) * 100));
        meterFill.style.width = `${trust}%`;
        meterFill.textContent = `${trust}%`;
        meterLabel.textContent = `${latest.classification} • confidence ${(latest.confidence||0).toFixed(2)}`;
        reasonEl.textContent = latest.reason || '';
      }
      renderHistory(hist);
    });
  }

  function renderHistory(list) {
    historyList.innerHTML = '';
    if (!list || list.length === 0) {
      historyList.innerHTML = '<div class="entry">No threats logged.</div>';
      return;
    }
    list.forEach(entry => {
      const d = document.createElement('div');
      d.className = 'entry';
      const time = new Date(entry.ts).toLocaleString();
      d.innerHTML = `<div><strong>${entry.classification}</strong> — ${entry.url}</div>
        <div class="meta">${time} • confidence ${(entry.confidence||0).toFixed(2)}</div>
        <div class="small">${entry.reason}</div>
        <div style="margin-top:6px"><button class="secondary explain" data-ts="${entry.ts}">Explain</button></div>`;
      historyList.appendChild(d);
    });
    historyList.querySelectorAll('.explain').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const ts = Number(e.target.dataset.ts);
        chrome.runtime.sendMessage({ type: 'get_history' }, (hist = []) => {
          const entry = hist.find(x => x.ts === ts);
          if (!entry) return;
          chrome.runtime.sendMessage({ type: 'explain_threat', entry }, (resp) => {
            alert(resp || 'Could not explain this entry.');
          });
        });
      });
    });
  }

  toggleBtn.addEventListener('click', () => {
    const pause = toggleBtn.textContent.includes('Pause');
    const newState = !pause;
    chrome.runtime.sendMessage({ type: 'toggle_protection', active: newState });
    toggleBtn.textContent = newState ? 'Pause Protection' : 'Resume Protection';
  });

  antivirusBtn.addEventListener('click', () => {
    shieldIcon.classList.add('pulse');
    chrome.runtime.sendMessage({ type: 'manual_block' });
    setTimeout(() => shieldIcon.classList.remove('pulse'), 700);
    setTimeout(refreshMeterFromHistory, 800);
  });

  clearHistory.addEventListener('click', () => {
    chrome.storage.local.set({ threatHistory: [] }, refreshMeterFromHistory);
  });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'ai_alert') {
      refreshMeterFromHistory();
    }
  });

  refreshMeterFromHistory();
});
# Chrome AI Security Shield — Adaptive Intelligence

AI-powered Chrome extension that analyzes page behavior using Gemini Nano (if available) and fallback heuristics, shows a Trust Meter, logs threats, and can auto-defend or let the user block malicious tabs.

## Features
- Live page telemetry collection and AI-assisted classification.
- Trust Meter visualized in popup (analysis tab).
- Manual “Antivirus (Block tab)” button and Auto-Defense for high-confidence threats.
- Threat History stored locally, with explainability via AI.
- Alerts: audio (alert.wav), system notifications, badge emoji pulses.

## Installation
1. Clone/download repo.
2. Open Chrome → `chrome://extensions/`.
3. Enable Developer mode → Load unpacked → Select `ChromeAISecurityShield/`.
4. Test on various sites.

## Files
See manifest.json, background.js, content_script.js, popup.html, popup.js, popup.css, alert.wav, icons/*

## License
MIT
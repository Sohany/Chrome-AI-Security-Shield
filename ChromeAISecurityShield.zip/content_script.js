// content_script.js
(function () {
  function collectFeatures() {
    const scriptCount = document.scripts.length || 0;
    const iframeCount = document.querySelectorAll('iframe').length || 0;
    const imagesCount = document.images.length || 0;
    const formsCount = document.forms.length || 0;
    const linksCount = document.querySelectorAll('a').length || 0;

    const url = location.href;
    const urlLower = url.toLowerCase();
    const isEcommerce = /cart|product|checkout|add-to-cart|basket|sku|shop|checkout/.test(urlLower)
      || !!document.querySelector('[data-product]') || !!document.querySelector('[data-cart]');
    const isSocial = /login|profile|feed|timeline|post|tweet|share|friends/.test(urlLower)
      || !!document.querySelector('[data-post]') || !!document.querySelector('[role=\"feed\"]');

    return { scriptCount, iframeCount, imagesCount, formsCount, linksCount, isEcommerce, isSocial, url, ts: Date.now() };
  }

  let runtimeScriptAdds = 0;
  let runtimeIframeAdds = 0;
  let postMsgCount = 0;
  try {
    const mo = new MutationObserver(muts => {
      muts.forEach(m => {
        m.addedNodes.forEach(n => {
          const t = n.tagName && n.tagName.toUpperCase();
          if (t === 'SCRIPT') runtimeScriptAdds++;
          if (t === 'IFRAME') runtimeIframeAdds++;
        });
      });
      sendTelemetry();
    });
    mo.observe(document.documentElement || document, { childList: true, subtree: true });
  } catch (e) {}

  try {
    const origPost = window.postMessage;
    window.postMessage = function () {
      postMsgCount++;
      sendTelemetry();
      return origPost.apply(this, arguments);
    };
  } catch (e) {}

  function sendTelemetry() {
    const f = collectFeatures();
    const features = {
      ...f,
      runtimeScriptAdds,
      runtimeIframeAdds,
      postMsgCount
    };
    try {
      chrome.runtime.sendMessage({ type: 'content_telemetry', features }, () => {});
    } catch (e) {
      // not in extension context
    }
  }

  sendTelemetry();
  setInterval(sendTelemetry, 5000);
})();
// background.js (module)
let protectionActive = true;
let blinking = false;
let blinkInterval = null;

async function appendThreatRecord(record) {
  try {
    const data = await chrome.storage.local.get('threatHistory');
    const list = data.threatHistory || [];
    list.unshift(record);
    if (list.length > 200) list.length = 200;
    await chrome.storage.local.set({ threatHistory: list });
  } catch (e) {
    console.warn('storage append failed', e);
  }
}

function localHeuristicScore(f) {
  let score = 0;
  score += Math.min(f.scriptCount / 20, 4);
  score += Math.min(f.iframeCount / 5, 4);
  score += Math.min((f.postMsgCount || 0) / 5, 3);
  if (f.isEcommerce) score += 1;
  if (f.isSocial) score += 0.8;
  if ((f.formsCount || 0) > 5) score += 1;
  return score;
}

async function analyzeWithAI(features) {
  const prompt = `
You are a security analyst assistant. Given telemetry, answer with JSON:
{ "classification": "Safe|Suspicious|Malicious", "confidence": 0..1, "reason": "short explanation" }

Telemetry:
${JSON.stringify(features, null, 2)}
  `.trim();

  try {
    if (typeof ai !== 'undefined' && ai.languageModel && ai.languageModel.create) {
      const session = await ai.languageModel.create({ model: 'gemini-nano' });
      const resp = await session.prompt(prompt, { max_output_tokens: 200 });
      const txt = (resp && (resp.text || resp.output)) || String(resp);
      try { return JSON.parse(txt); } catch (e) { return { classification: txt.includes('Malicious') ? 'Malicious' : txt.includes('Suspicious') ? 'Suspicious' : 'Safe', confidence: 0.75, reason: txt.slice(0,200) }; }
    } else if (typeof chrome !== 'undefined' && chrome.ai && chrome.ai.languageModel && chrome.ai.languageModel.create) {
      const session = await chrome.ai.languageModel.create({ model: 'gemini-nano' });
      const resp = await session.prompt(prompt);
      const txt = resp?.text || String(resp);
      try { return JSON.parse(txt); } catch { return { classification: txt.includes('Malicious') ? 'Malicious' : txt.includes('Suspicious') ? 'Suspicious' : 'Safe', confidence: 0.7, reason: txt.slice(0,200) }; }
    }
  } catch (e) {
    console.warn('AI call failed', e);
  }

  const s = localHeuristicScore(features);
  const confidence = Math.min(1, s / 8);
  const classification = s >= 4.5 ? 'Malicious' : s >= 2.5 ? 'Suspicious' : 'Safe';
  const reason = `heuristic score ${s.toFixed(2)}`;
  return { classification, confidence, reason };
}

async function triggerAlert(analysis, features) {
  const msg = `${analysis.classification}: ${analysis.reason || ''} (confidence ${(analysis.confidence||0).toFixed(2)})`;
  try {
    const audio = new Audio(chrome.runtime.getURL('alert.wav'));
    await audio.play().catch(()=>{});
  } catch(e) {}

  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'AI Security Shield Alert',
    message: msg
  });

  const rec = {
    ts: Date.now(),
    url: features.url,
    classification: analysis.classification,
    confidence: analysis.confidence || 0,
    reason: analysis.reason || 'no reason'
  };
  appendThreatRecord(rec);

  chrome.runtime.sendMessage({ type: 'ai_alert', analysis: rec });

  startBlinkingIcon();
}

function startBlinkingIcon() {
  if (blinking) return;
  blinking = true;
  let visible = true;
  blinkInterval = setInterval(() => {
    chrome.action.setBadgeText({ text: visible ? '🛡️' : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#FFD700' });
    visible = !visible;
  }, 500);
  setTimeout(stopBlinkingIcon, 4000);
}
function stopBlinkingIcon() {
  if (!blinking) return;
  clearInterval(blinkInterval);
  blinking = false;
  chrome.action.setBadgeText({ text: '' });
}

async function autoDefendTab(tabId) {
  try {
    await chrome.tabs.remove(tabId);
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'AI Shield — Auto-Defend',
      message: 'Potentially malicious tab was closed automatically.'
    });
  } catch (e) {
    console.warn('autoDefendTab failed', e);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === 'content_telemetry' && protectionActive) {
      const features = msg.features;
      const analysis = await analyzeWithAI(features);
      const isThreat = (analysis.classification === 'Malicious' || (analysis.classification === 'Suspicious' && (analysis.confidence||0) >= 0.7));
      if (isThreat) {
        await triggerAlert(analysis, features);
        if (analysis.classification === 'Malicious' || (analysis.confidence||0) > 0.9) {
          const tabId = sender.tab && sender.tab.id;
          if (tabId) await autoDefendTab(tabId);
        }
      }
    } else if (msg.type === 'toggle_protection') {
      protectionActive = msg.active;
    } else if (msg.type === 'manual_block') {
      const tabId = sender.tab && sender.tab.id;
      if (tabId) {
        await autoDefendTab(tabId);
      }
    } else if (msg.type === 'get_history') {
      const store = await chrome.storage.local.get('threatHistory');
      sendResponse && sendResponse(store.threatHistory || []);
    } else if (msg.type === 'explain_threat' && msg.entry) {
      const explanation = await explainWithAI(msg.entry);
      sendResponse && sendResponse(explanation);
    }
  })();
  return true;
});

async function explainWithAI(entry) {
  const prompt = `
You are an assistant that explains security findings to non-technical users.
Given this record: ${JSON.stringify(entry)}, write one short paragraph (max 40 words) explaining why this page was flagged and what the user should do.
`;
  try {
    if (typeof ai !== 'undefined' && ai.languageModel && ai.languageModel.create) {
      const session = await ai.languageModel.create({ model: 'gemini-nano' });
      const resp = await session.prompt(prompt, { max_output_tokens: 120 });
      return resp?.text || resp?.response || `Flagged: ${entry.reason}`;
    } else if (typeof chrome !== 'undefined' && chrome.ai && chrome.ai.languageModel && chrome.ai.languageModel.create) {
      const s = await chrome.ai.languageModel.create({ model: 'gemini-nano' });
      const r = await s.prompt(prompt);
      return r?.text || String(r);
    }
  } catch (e) {
    console.warn('explainWithAI failed', e);
  }
  return `Flagged because: ${entry.reason}. Consider closing the page or avoiding entering sensitive info.`;
}